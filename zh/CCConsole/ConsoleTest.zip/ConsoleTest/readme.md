测试工程使用说明：

自行下载 Cocos2d-x v3.0

将cocos2d拷贝到ConsoleTest下。